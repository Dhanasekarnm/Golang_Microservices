from robocorp.tasks import task
from RPA.Browser.Selenium import Selenium
from time import sleep
from RPA.HTTP import HTTP

@task
def minimal_task():
    message = "Hello"
    message = message + " World!"
   
    http = HTTP()
    http.download(
        url="https://robotsparebinindustries.com/SalesData.xlsx",
        overwrite=True)

   lib = Selenium()

   lib.open_available_browser("https://robotsparebinindustries.com/")
   lib.input_text("css=#username", "maria")
   lib.input_text("css=#password", "thoushallnotpass")
   lib.click_button("css=.btn")
   sleep(10)

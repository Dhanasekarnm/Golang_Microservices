import os
from robocorp.tasks import task
from time import sleep
from RPA.Browser import Browser
from RPA.HTTP import HTTP

browser = Browser()

@task
def minimal_task():
    message = "Hello"
    message = message + " World!"
    print(message)
    print("Web UI started")
    browser.open_chrome_browser("https://robotsparebinindustries.com/")

    browser.input_text("css=#username", "maria")
    browser.input_text("css=#password", "thoushallnotpass")
    browser.click_button("css=.btn")
    sleep(10)
    http = HTTP()
    http.download(
        url="https://robotsparebinindustries.com/SalesData.xlsx",
        overwrite=True)
    browser.screenshot(
        filename=f"{os.getcwd()}/output/sales_summary.png",
        locator="css=div.logout")
    print("Web UI Completed")
